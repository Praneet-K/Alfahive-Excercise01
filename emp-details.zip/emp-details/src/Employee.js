import React from 'react'

function Employee() {
    var Emp=[]
    var url = "http://localhost:8080/api/employees";
        const options = {method:'GET'}
        fetch(url,options)
            .then(response => response.json())
            .then(data => {
                data.map(x => {
                    console.log(Emp.push(x))})
            })
  return (
    <tbody>
        {Emp.map(x =><tr key = {x.id}>
                    <td>hi{x.firstName}</td>
                    <td>{x.lastName}</td>
                    <td>{x.phno}</td>
                    <td>{`${x.address} , ${x.city} , ${x.state} , ${x.country}`}</td>
                    </tr>)}
        </tbody>
  )
}

export default Employee
