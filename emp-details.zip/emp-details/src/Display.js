import React, { Component } from 'react'
class Display extends Component{
    EmpD = []
    constructor(props) {
        super(props)
        this.state = {
        };
    }
    async componentDidMount(){
        var url = "http://localhost:8080/api/employees";
        const options = {method:'GET'}
        await fetch(url,options)
            .then(response => response.json())
            .then(data => {
                data.map(x => {
                    this.EmpD.push(x)})
            })
        console.log(this.EmpD)  //actual data is logging out
        console.log(this.EmpD.length)  //expected length is printed
    }
    render(){
        // console.log(this.EmpD)  
        console.log(this.EmpD.length)  //0
        return (
            <>
                <table>
                    <thead>
                        <tr>
                        <th>FirstName</th>
                        <th>LastName</th>
                        <th>PhoneNumber</th>
                        <th>Address</th></tr>
                    </thead>
                    <tbody>
                    {this.EmpD.map(x =><tr key = {x.id}>
                                <td>hi{x.firstName}</td>
                                <td>{x.lastName}</td>
                                <td>{x.phno}</td>
                                <td>{`${x.address} , ${x.city} , ${x.state} , ${x.country}`}</td>
                                </tr>)}
                    </tbody>
                </table>
            </>
        )
    }
}

export default Display;